package com.example.unitconverter;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.text.DecimalFormat;


public class MainActivity extends AppCompatActivity  {

    Spinner spinner;
    EditText number;
    TextView unit1, unit2, unit3, result1, result2, result3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        spinner = findViewById(R.id.spinner);
        number = findViewById(R.id.number);
        unit1 = findViewById(R.id.unit1);
        unit2 = findViewById(R.id.unit2);
        unit3 = findViewById(R.id.unit3);
        result1 = findViewById(R.id.result1);
        result2 = findViewById(R.id.result2);
        result3 = findViewById(R.id.result3);


        String[] units = {"Metres","Celsius","Kilograms"};
        ArrayAdapter adapter = new ArrayAdapter<String>(this, R.layout.support_simple_spinner_dropdown_item, units);
        spinner.setAdapter(adapter);



    }
    DecimalFormat df = new DecimalFormat("#.00");
    String numOne, numTwo, numThree;

    public void lengResult(View view){
        result1.setText(" ");
        result2.setText(" ");
        result3.setText(" ");
        unit1.setText(" ");
        unit2.setText(" ");
        unit3.setText(" ");
        double resultOne = Double.parseDouble(number.getText().toString()) * 100;
        double resultTwo = Double.parseDouble(number.getText().toString()) * 3.28;
        double resultThree = Double.parseDouble(number.getText().toString()) * 39.37;
        numOne = df.format(resultOne);
        numTwo = df.format(resultTwo);
        numThree = df.format(resultThree);
        result1.setText(numOne);
        result2.setText(numTwo);
        result3.setText(numThree);
        unit1.setText("Centimetres");
        unit2.setText("Feet");
        unit3.setText("Inches");
    }

    public void weightResult(View view){
        result1.setText(" ");
        result2.setText(" ");
        result3.setText(" ");
        unit1.setText(" ");
        unit2.setText(" ");
        unit3.setText(" ");
        double resultOne = Double.parseDouble(number.getText().toString()) * 1000;
        double resultTwo = Double.parseDouble(number.getText().toString()) * 35.27;
        double resultThree = Double.parseDouble(number.getText().toString()) * 2.2;
        numOne = df.format(resultOne);
        numTwo = df.format(resultTwo);
        numThree = df.format(resultThree);
        result1.setText(numOne);
        result2.setText(numTwo);
        result3.setText(numThree);
        unit1.setText("Grams");
        unit2.setText("Ounzes(Oz)");
        unit3.setText("Pounds");
    }

    public void tempResult(View view){
        result1.setText(" ");
        result2.setText(" ");
        result3.setText(" ");
        unit1.setText(" ");
        unit2.setText(" ");
        unit3.setText(" ");
        double resultOne = Double.parseDouble(number.getText().toString()) * 1.4 + 32;
        double resultTwo = Double.parseDouble(number.getText().toString()) + 273.15;
        numOne = df.format(resultOne);
        numTwo = df.format(resultTwo);
        result1.setText(numOne);
        result2.setText(numTwo);
        unit1.setText("Fahrenheit");
        unit2.setText("Kelvin");
    }


}